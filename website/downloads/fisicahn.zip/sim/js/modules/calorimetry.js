/**
 * @fileoverview Calorimetría y cambios de fase — mezclas, meseta de fusión y
 * los tres mecanismos de transferencia de calor (tanda 5.3).
 *
 * Modos:
 * - `mezcla`: dos cuerpos (agua + metal) alcanzan T_eq; la gráfica T(t) muestra
 *   el relajamiento exponencial y el calor cedido/absorbido Q.
 * - `fase`: hielo calentado a potencia constante P. La curva T vs Q muestra la
 *   meseta de fusión: T se queda clavada en 0 °C mientras llega el calor latente.
 * - `conduccion`: barra entre focos T₁/T₂ con P = k·A·ΔT/L y perfil lineal T(x).
 * - `conveccion`: ley de enfriamiento de Newton P = h·A·ΔT con lazo de fluido.
 * - `radiacion`: Stefan-Boltzmann P = ε·σ·A·(T⁴ − Tₐ⁴); el cuerpo brilla más
 *   con la temperatura (desplazamiento del pico de emisión).
 *
 * Ejercita `plot` (con `fill`), `fill`, `chip` y `readout`. La mezcla tiene
 * solución analítica (no hay integración temporal); la fase y la transferencia
 * avanzan con el tiempo acumulado.
 */

import { SimModule } from '../core/sim-module.js';
import { roundTo, smoothstep } from '../core/geometry.js';
import { thermalColor } from '../core/draw-primitives.js';

const C_WATER = 4186; // J/(kg·K)
const C_ICE = 2090; // J/(kg·K)
const L_FUSION = 334000; // J/kg
const SIGMA = 5.67e-8; // Stefan-Boltzmann

/**
 * Muestras metálicas «desconocidas» al estilo del calorímetro de educaplus:
 * el alumno mide T_eq, despeja c con m₂·c·(T₂ − T_eq) = m₁·c_agua·(T_eq − T₁)
 * y compara con la tabla de la pestaña Información para identificar el metal.
 * c en J/(kg·K).
 */
export const SAMPLES = {
  A: { c: 897, metal: 'aluminio' },
  B: { c: 450, metal: 'hierro' },
  C: { c: 385, metal: 'cobre' },
  D: { c: 128, metal: 'plomo' },
  E: { c: 388, metal: 'zinc' },
  F: { c: 235, metal: 'plata' }
};
/** Segundos que tarda la muestra en caer al agua al iniciar (animación). */
const T_DROP = 1.2;

export default class Calorimetry extends SimModule {
  static viewport = { width: 24, height: 16 };

  /**
   * Encuadre propio de cada modo: el calorímetro es alto y estrecho, mientras
   * que la barra entre focos es ancha y baja. Con un único encuadre de 24 × 16
   * la mezcla salía pequeña y arrinconada y la radiación se salía por arriba.
   */
  static views = {
    mezcla: { width: 15.5, height: 13.5 },
    fase: { width: 15.5, height: 13.5 },
    conduccion: { width: 25, height: 11 },
    conveccion: { width: 25, height: 11 },
    radiacion: { width: 25, height: 11 }
  };

  // Punto fijo del mecanismo en el origen del mundo (WAVE 17.1).
  static anchor = { x: 0, y: 0 };

  static params = [
    {
      id: 'modo',
      type: 'select',
      label: 'Modo',
      value: 'mezcla',
      options: [
        { value: 'mezcla', label: 'Mezcla y equilibrio' },
        { value: 'fase', label: 'Cambios de fase' },
        { value: 'conduccion', label: 'Conducción' },
        { value: 'conveccion', label: 'Convección' },
        { value: 'radiacion', label: 'Radiación' }
      ]
    },
    {
      id: 'muestra',
      showIf: { modo: 'mezcla' },
      type: 'select',
      label: 'Muestra metálica',
      value: 'manual',
      options: [
        { value: 'manual', label: 'Metal con c conocido (ajustable)' },
        { value: 'A', label: 'Muestra desconocida A' },
        { value: 'B', label: 'Muestra desconocida B' },
        { value: 'C', label: 'Muestra desconocida C' },
        { value: 'D', label: 'Muestra desconocida D' },
        { value: 'E', label: 'Muestra desconocida E' },
        { value: 'F', label: 'Muestra desconocida F' }
      ]
    },
    { id: 'revelar', type: 'checkbox', label: 'Revelar c de la muestra', value: false, showIf: { modo: 'mezcla' } },
    { id: 'm1', label: 'Masa de agua', latex: 'm_1', unit: 'kg', min: 0.1, max: 4, step: 0.1, value: 1, showIf: { modo: 'mezcla' } },
    { id: 'T1', label: 'T agua', latex: 'T_1', unit: '°C', min: -20, max: 90, step: 1, value: 20, showIf: { modo: ['mezcla', 'conduccion', 'conveccion', 'radiacion'] } },
    { id: 'm2', label: 'Masa del metal', latex: 'm_2', unit: 'kg', min: 0.1, max: 4, step: 0.1, value: 1, showIf: { modo: 'mezcla' } },
    { id: 'c2', label: 'c del metal', latex: 'c_2', unit: 'J/(kg·K)', min: 100, max: 2000, step: 50, value: 450, showIf: { modo: 'mezcla', muestra: 'manual' } },
    { id: 'T2', label: 'T del metal', latex: 'T_2', unit: '°C', min: -20, max: 300, step: 5, value: 150, showIf: { modo: ['mezcla', 'conduccion', 'conveccion'] } },
    { id: 'mIce', label: 'Masa de hielo', latex: 'm', unit: 'kg', min: 0.05, max: 2, step: 0.05, value: 0.5, showIf: { modo: 'fase' } },
    { id: 'P', label: 'Potencia del foco', latex: 'P', unit: 'W', min: 20, max: 600, step: 20, value: 200, showIf: { modo: 'fase' } },
    { id: 'k', label: 'Conductividad k', latex: 'k', unit: 'W/(m·K)', min: 0.1, max: 400, step: 5, value: 50, showIf: { modo: 'conduccion' } },
    { id: 'h', label: 'Coef. convección', latex: 'h', unit: 'W/(m²·K)', min: 5, max: 500, step: 5, value: 50, showIf: { modo: 'conveccion' } },
    { id: 'A', label: 'Sección', latex: 'A', unit: 'm²', min: 0.01, max: 2, step: 0.01, value: 0.05, showIf: { modo: ['conduccion', 'conveccion', 'radiacion'] } },
    { id: 'L', label: 'Longitud', latex: 'L', unit: 'm', min: 0.2, max: 4, step: 0.1, value: 1, showIf: { modo: 'conduccion' } },
    { id: 'eps', label: 'Emisividad ε', latex: '\\varepsilon', min: 0.05, max: 1, step: 0.05, value: 0.9, showIf: { modo: 'radiacion' } },
    { id: 'Tamb', label: 'T ambiente', latex: 'T_a', unit: '°C', min: -20, max: 40, step: 1, value: 15, showIf: { modo: 'radiacion' } }
  ];

  constructor(ctx) {
    super(ctx);
    this.params = {
      modo: 'mezcla',
      muestra: 'manual',
      revelar: false,
      m1: 1,
      T1: 20,
      m2: 1,
      c2: 450,
      T2: 150,
      mIce: 0.5,
      P: 200,
      k: 50,
      h: 50,
      A: 0.05,
      L: 1,
      eps: 0.9,
      Tamb: 15
    };
    /** Tiempo acumulado del proceso en curso (fase y transferencia). */
    this.t = 0;
    /** Calor acumulado entregado al hielo (modo fase). */
    this.Q = 0;
    /** Escala del termómetro: marcas cacheadas por rango, y la marca viva de T_eq. */
    this._ticks = [];
    this._tickKey = '';
    this._tEqMark = [{ t: 0, label: 'T_eq', color: 'energy' }];
  }

  init(meta = null) {
    this.reset();
    this.setModuleInfo({
      title: 'Calorimetría',
      blurb: 'Equilibrio térmico, calor latente con meseta de fusión y los tres modos de transferencia.',
      story:
        'El calor es energía en tránsito. Cuando dos cuerpos se tocan, el calor fluye hasta igualar temperaturas; cuando un sólido funde, la temperatura se detiene mientras el calor latente rompe los enlaces. Y hay tres caminos para transferir calor: conducción (contacto), convección (fluido que se mueve) y radiación (ondas que viajan en el vacío).',
      sections: [
        {
          title: 'Práctica con el calorímetro:',
          text:
            'elige una muestra desconocida (A–F), fija masas y temperaturas, deja que se equilibre y despeja c con m₂·c·(T₂ − T_eq) = m₁·c_agua·(T_eq − T₁). Compara con la tabla: aluminio 897 · hierro 450 · zinc 388 · cobre 385 · plata 235 · plomo 128 J/(kg·K). Activa «Revelar c» para comprobar.',
          tone: 'accent'
        }
      ],
      cases: [
        'Metal caliente en agua: T_eq entre ambos, la gráfica muestra el relajamiento exponencial.',
        'Hielo a 0 °C: la curva T–Q se queda horizontal mientras funde: esa meseta es el calor latente.',
        'Conducción: a mayor k (cobre vs madera), más potencia fluye.',
        'Radiación: la potencia depende de T⁴: el cuerpo brillante pierde mucho más que el tibio.'
      ]
    });
    this.setModuleFormulas({
      title: 'Calorimetría',
      items: [
        {
          name: 'Calor sensible',
          formula: 'Q = m \\cdot c \\cdot \\Delta T',
          note: 'Calor necesario para cambiar la temperatura sin cambiar de fase.'
        },
        {
          name: 'Calor latente',
          formula: 'Q = m \\cdot L_f',
          note: 'Temperatura constante durante la fusión/solidificación.'
        },
        {
          name: 'Equilibrio térmico',
          formula: 'm_1 c_1 (T_f - T_1) + m_2 c_2 (T_f - T_2) = 0',
          note: 'La suma del calor cedido y absorbido es cero.'
        },
        {
          name: 'Conducción (Fourier)',
          formula: 'P = k\\, A\\, \\frac{T_1 - T_2}{L}',
          note: 'Proporcional al gradiente de temperatura.'
        },
        {
          name: 'Convección (Newton)',
          formula: 'P = h\\, A\\, \\Delta T',
          note: 'Coeficiente h según fluido y geometría.'
        },
        {
          name: 'Radiación (Stefan-Boltzmann)',
          formula: 'P = \\varepsilon \\sigma A (T^4 - T_a^4)',
          note: 'T en kelvin; la potencia crece con T⁴.'
        }
      ]
    });
    this.clearChallenges();
    this.setModuleGraphs(this.graphData());
  }

  /** Gráfica complementaria para el panel Gráficas (fuera del lienzo). */
  graphData() {
    if (this.params.modo === 'mezcla') {
      const Teq = this.tEq();
      return {
        title: 'Temperaturas en el calorímetro',
        description: `Equilibrio térmico final Teq = ${roundTo(Teq, 1)} °C entre el agua y el metal.`,
        unit: '°C',
        items: [
          { label: 'Agua (T₁)', value: roundTo(this.params.T1, 1), active: false },
          { label: 'Metal (T₂)', value: roundTo(this.params.T2, 1), active: false },
          { label: 'Equilibrio (Teq)', value: roundTo(Teq, 1), active: true }
        ]
      };
    }
    return null;
  }

  reset() {
    this.t = 0;
    this.Q = 0;
    const v = Calorimetry.views[this.params.modo] || Calorimetry.views.mezcla;
    this.frameWorld(v.width, v.height);
    this.engine?.reset?.();
  }

  /** Calor específico efectivo del metal: el ajustable o el de la muestra oculta. */
  cMetal() {
    const sample = SAMPLES[this.params.muestra];
    return sample ? sample.c : this.params.c2;
  }

  /** ¿Se muestra el valor de c? (metal conocido, o muestra revelada). */
  cVisible() {
    return !SAMPLES[this.params.muestra] || !!this.params.revelar;
  }

  /** Temperatura de equilibrio de la mezcla (análitica, con C = m·c). */
  tEq() {
    const C1 = this.params.m1 * C_WATER;
    const C2 = this.params.m2 * this.cMetal();
    return (C1 * this.params.T1 + C2 * this.params.T2) / (C1 + C2);
  }

  /** Constante de tiempo del relajamiento térmico (s, arbitraria pero coherente). */
  tauMix() {
    const C1 = this.params.m1 * C_WATER;
    const C2 = this.params.m2 * this.cMetal();
    return 6 / (1 + (C1 + C2) / 5000);
  }

  /** Temperatura del hielo según el calor acumulado (segmentos con meseta). */
  phaseTemp(Q) {
    const m = this.params.mIce;
    const Q1 = m * C_ICE * 20; // −20 → 0 °C
    if (Q <= Q1) return -20 + (Q / Q1) * 20;
    const Q2 = Q1 + m * L_FUSION;
    if (Q <= Q2) return 0; // meseta: fusión
    return (Q - Q2) / (m * C_WATER); // 0 → T
  }

  /** Potencia transferida según el canal activo (en W). */
  transferPower() {
    const { modo, k, h, A, L, T1, T2, eps, Tamb } = this.params;
    const dT = T1 - T2;
    if (modo === 'conduccion') return k * A * dT / Math.max(L, 0.01);
    if (modo === 'conveccion') return h * A * dT;
    const Tk = T1 + 273.15;
    const Tak = Tamb + 273.15;
    return Math.max(0, eps * SIGMA * A * (Math.pow(Tk, 4) - Math.pow(Tak, 4)));
  }

  /** Temperatura del cuerpo caliente (K→°C) en el modo radiación. */
  radC() {
    return this.params.T1;
  }

  update(dt) {
    this.t += dt;
    // Sólo el modo fase integra en el tiempo (calor acumulado); la mezcla
    // tiene solución analítica y las gráficas se muestrean al dibujar.
    if (this.params.modo === 'fase') this.Q += this.params.P * dt;
  }

  /** Temperatura del agua en el instante actual (aprox. exponencial a T_eq). */
  mixWater() {
    return this.tEq() + (this.params.T1 - this.tEq()) * Math.exp(-this.mixClock() / this.tauMix());
  }

  /** Temperatura del metal en el instante actual. */
  mixMetal() {
    return this.tEq() + (this.params.T2 - this.tEq()) * Math.exp(-this.mixClock() / this.tauMix());
  }

  /** Tiempo de intercambio: empieza cuando la muestra ya cayó al agua. */
  mixClock() {
    return Math.max(0, Math.min(this.t, 90) - T_DROP);
  }

  /* ---------- dibujo declarativo (§2.4) ---------- */

  draw(scene) {
    const hud = scene.hud;
    const vp = scene.viewport();

    if (this.params.modo === 'mezcla') this._drawMix(scene, hud, vp);
    else if (this.params.modo === 'fase') this._drawPhase(scene, hud, vp);
    else this._drawTransfer(scene, hud, vp);
  }

  /**
   * Modo mezcla — calorímetro de laboratorio (al estilo de educaplus): vaso
   * aislado con agua y termómetro, la muestra metálica caliente cae al agua
   * al arrancar y las dos temperaturas convergen en vivo a T_eq. Con una
   * muestra desconocida el objetivo es despejar su c a partir de T_eq.
   */
  _drawMix(scene, hud, vp) {
    const { m1, T1, m2, T2 } = this.params;
    const Teq = this.tEq();
    const tau = this.tauMix();
    const Tw = this.mixWater();
    const Tm = this.mixMetal();
    const clock = this.mixClock();
    const prog = 1 - Math.exp(-clock / tau); // avance hacia el equilibrio
    const tLow = Math.min(T1, T2, Teq);
    const tHigh = Math.max(T1, T2, Teq);
    const span = Math.max(1e-6, tHigh - tLow);
    const sample = SAMPLES[this.params.muestra];
    const sampleName = sample ? `Muestra ${this.params.muestra}` : 'Metal';
    // Caída de la muestra: de la pinza (arriba) al fondo del vaso.
    const drop = Math.min(1, this.t / T_DROP);
    const ease = smoothstep(0, 1, drop);

    /* ---- Calorímetro: vaso exterior aislante, vaso interior y tapa ---- */
    const cxV = 0.6; // el conjunto (termómetro + vaso + muestra) queda centrado
    const W = 8.4;
    const Hh = 7.2;
    const yC = -0.6;
    scene.rect(cxV, yC, W + 1.2, Hh + 0.9, { color: 'textDim', width: 2.4, fill: 'rgba(90,100,120,0.18)', radius: 6 });
    // Aislante: rayado entre las dos paredes del vaso (una primitiva por lado).
    const yIns0 = yC + Hh / 2 + 0.45;
    const yIns1 = yC - Hh / 2 - 0.45;
    const lineScale = scene.theme?.lineScale || 1;
    const insOpts = { width: 1, spacing: scene.px(0.5) / lineScale, length: scene.px(0.72) / lineScale };
    scene.hatch(cxV - W / 2 - 0.6, yIns0, cxV - W / 2 - 0.6, yIns1, { ...insOpts, side: 1 });
    scene.hatch(cxV + W / 2 + 0.6, yIns0, cxV + W / 2 + 0.6, yIns1, { ...insOpts, side: -1 });
    scene.rect(cxV, yC, W, Hh, { color: 'textDim', width: 1.6 });
    scene.label(cxV, yC - Hh / 2 - 0.95, 'calorímetro (aislado)', { avoid: true, color: 'textDim', size: 11 });
    // Tapa con agujeros para termómetro y pinza.
    scene.rect(cxV, yC + Hh / 2 + 0.25, W + 1.2, 0.5, { color: 'textDim', fill: 'textDim', alpha: 0.7, width: 1 });

    /* ---- Agua ---- */
    const waterTone = thermalColor('#1e6fd9', '#ff8a3d', (Tw - tLow) / span);
    const waterH = 4.2 + 0.8 * Math.min(1, m1 / 4);
    const waterTop = yC - Hh / 2 + waterH;
    scene.fill(cxV, waterTop, W, waterH, { color: waterTone, alpha: 0.5, waves: true });
    scene.label(cxV + 1.3, waterTop - 0.7, `agua ${m1} kg · ${roundTo(Tw, 1)} °C`, { avoid: true, color: 'field', size: 11 });

    /* ---- Muestra metálica: cuelga de la pinza y cae al agua ---- */
    const side = 1.1 + 0.6 * Math.min(1, m2 / 4);
    const yTopPos = yC + Hh / 2 + 2.4;
    const yBottomPos = yC - Hh / 2 + side / 2 + 0.15;
    const yM = yTopPos + (yBottomPos - yTopPos) * ease;
    const xM = cxV + 1.9;
    const metalTone = thermalColor('#5b6b7a', '#ff5a36', (Tm - tLow) / span);
    // Hilo de la pinza.
    scene.line(xM, yC + Hh / 2 + 3.6, xM, yM + side / 2, { color: 'textDim', width: 1.2 });
    scene.rect(xM, yM, side, side, { color: metalTone, width: 2.2, fill: metalTone, fillAlpha: 0.75, radius: 3 });
    scene.label(xM, yM + side / 2 + 0.45, `${sampleName} ${m2} kg · ${roundTo(Tm, 1)} °C`, { avoid: true, color: 'force', size: 11 });
    // Etiqueta del calor específico sobre la propia muestra: con la casilla
    // «Revelar» marcada aparece el dato; sin marcar, la incógnita. Antes la
    // casilla sólo cambiaba un texto del HUD y en la escena no se notaba.
    scene.label(xM, yM - side / 2 - 0.45, this.cVisible() ? `c = ${roundTo(this.cMetal(), 0)} J/(kg·K)` : 'c = ?', {
      avoid: true,
      color: this.cVisible() ? 'energy' : 'textDim',
      size: 11,
      baseline: 'top'
    });
    if (drop >= 1 && prog < 0.985) {
      // Ondas de calor del metal al agua.
      for (let j = 0; j < 3; j++) {
        const ph = (this.t * 0.8 + j / 3) % 1;
        const rr = side * 0.7 + ph * 1.4;
        scene.arc(xM, yM, rr, 0, Math.PI * 2, { color: 'energy', width: 1.2, alpha: 0.5 * (1 - ph), dash: [3, 3] });
      }
    }

    /* ---- Termómetro del agua (columna proporcional a T agua) ---- */
    const xT = cxV - 2.6;
    const tTop = yC + Hh / 2 + 1.4;
    const tBot = yC - Hh / 2 + 0.6;
    const tScaleLo = Math.floor((tLow - 10) / 10) * 10;
    const tScaleHi = Math.ceil((tHigh + 10) / 10) * 10;
    const tSpan = Math.max(1e-6, tScaleHi - tScaleLo);
    const tFrac = (val) => Math.max(0, Math.min(1, (val - tScaleLo) / tSpan));
    // Marcas de la escala: sólo se reconstruyen cuando cambia el rango.
    const tickKey = tScaleLo + '|' + tScaleHi;
    if (this._tickKey !== tickKey) {
      const ticks = [];
      for (let tv = tScaleLo; tv <= tScaleHi; tv += 10) {
        const major = tv % 50 === 0;
        ticks.push({ t: tFrac(tv), label: major ? String(tv) : undefined, major });
      }
      this._ticks = ticks;
      this._tickKey = tickKey;
    }
    this._tEqMark[0].t = tFrac(Teq);
    scene.thermometer(xT, tBot, tTop - tBot, tFrac(Tw), { color: 'force', tube: 'textDim', ticks: this._ticks, marks: this._tEqMark });
    scene.label(xT, tTop + 0.55, `${roundTo(Tw, 1)} °C`, { color: 'force', size: 12, avoid: true });

    /* ---- Estado ---- */
    const status =
      drop < 1
        ? 'La muestra caliente cae al agua…'
        : prog >= 0.985
          ? `EQUILIBRIO: T_eq = ${roundTo(Teq, 1)} °C`
          : `Intercambio de calor: T_eq → ${roundTo(Teq, 1)} °C`;
    // El estado va al HUD: sobre el vaso se salía del encuadre alto.
    hud.chip(status, 'top-left', { color: 'energy' });
    hud.chip(
      sample && !this.params.revelar
        ? `${sampleName}: c desconocido → despéjalo con T_eq`
        : `${sampleName}: c = ${roundTo(this.cMetal(), 0)} J/(kg·K)${sample ? ' (' + sample.metal + ')' : ''}`,
      'top-left',
      { color: 'energy' }
    );

    const rows = [
      { label: 'T_eq', value: roundTo(Teq, 2), unit: '°C' },
      { label: 'Q agua', value: roundTo(m1 * C_WATER * (Teq - T1), 0), unit: 'J' },
      { label: 'Q metal', value: roundTo(m2 * this.cMetal() * (T2 - Teq), 0), unit: 'J' }
    ];
    hud.readout(rows, 'bottom-left');

    if (vp.w > 430) {
      // T(t) con relajamiento exponencial: la mezcla tiende a T_eq en vivo.
      const horizon = Math.max(clock, 1);
      const last = { x: clock, w: Tw, m: Tm };
      hud.plot(
        { x: vp.x + vp.w - 250, y: vp.y + vp.h - 128, w: 235, h: 116 },
        {
          title: 'Temperatura T(t) en el calorímetro',
          series: [
            { fn: (tt) => Teq + (T1 - Teq) * Math.exp(-tt / tau), samples: 60, color: 'field', label: 'agua' },
            { fn: (tt) => Teq + (T2 - Teq) * Math.exp(-tt / tau), samples: 60, color: 'force', label: 'metal' },
            { points: [{ x: 0, y: Teq }, { x: horizon, y: Teq }], color: 'energy', dash: [3, 3], label: 'T_eq' },
            { points: [{ x: last.x, y: last.w - 0.02 }, { x: last.x, y: last.w + 0.02 }], color: 'field', width: 2.5 },
            { points: [{ x: last.x, y: last.m - 0.02 }, { x: last.x, y: last.m + 0.02 }], color: 'force', width: 2.5 }
          ],
          xRange: [0, horizon],
          yRange: [tLow - 10, tHigh + 10]
        }
      );
    }
  }

  /** Modo fase: T vs Q con la meseta de fusión bien visible. */
  _drawPhase(scene, hud, vp) {
    const { mIce, P } = this.params;
    const Q1 = mIce * C_ICE * 20;
    const Q2 = Q1 + mIce * L_FUSION;
    const T = this.phaseTemp(this.Q);
    const fase = this.Q < Q1 ? 'hielo' : this.Q < Q2 ? 'fusión' : 'agua';

    // Recipiente centrado, con termómetro a la izquierda y foco de calor
    // debajo: el montaje ocupa el encuadre en vez de una esquina.
    const level = this.Q < Q1 ? 0.35 : this.Q < Q2 ? 0.35 + (0.5 * (this.Q - Q1)) / (Q2 - Q1) : 1;
    const cxP = 1.2;
    const wP = 7;
    const hP = 7;
    const cyP = 0.6;
    const yBot = cyP - hP / 2;
    scene.rect(cxP, cyP, wP, hP, { color: 'textDim', width: 2, fill: 'rgba(79,195,247,0.10)' });
    scene.fill(cxP, yBot + hP * level, wP - 0.2, hP * level, {
      color: this.Q < Q2 ? 'mass' : 'energy',
      alpha: 0.3,
      waves: level < 1 && this.Q >= Q1
    });
    scene.hatch(cxP - wP / 2, yBot, cxP + wP / 2, yBot, { side: -1, color: 'textDim' });
    scene.label(cxP, cyP + hP / 2 + 0.5, `Hielo → agua: ${mIce} kg`, { avoid: true, color: 'mass' });

    // Foco de calor: la llama crece con la potencia (P dejaba de verse en la escena).
    const flameH = 0.7 + (P / 600) * 1.6;
    scene.flame(cxP, yBot - 0.15 - flameH, { h: flameH, w: flameH * 0.6, t: this.t });
    scene.label(cxP, yBot - 0.35 - flameH, `P = ${P} W`, { avoid: true, color: 'energy', baseline: 'top' });

    // Termómetro con la temperatura de la muestra (−20 … +60 °C).
    scene.thermometer(cxP - wP / 2 - 1.6, yBot, hP, (T + 20) / 80, {
      label: `${roundTo(T, 1)} °C`,
      marks: [{ t: 20 / 80, label: '0 °C' }]
    });

    scene.chip(cxP - 1.6, cyP - hP / 2 - 0.001 + 0.9, `Fase: ${fase}`, { avoid: true, color: 'energy' });
    scene.chip(cxP + 1.8, cyP - hP / 2 + 0.9, `T = ${roundTo(T, 1)} °C`, { avoid: true, color: 'mass' });

    hud.readout(
      [
        { label: 'T', value: roundTo(T, 2), unit: '°C' },
        { label: 'Q aportado', value: roundTo(this.Q / 1000, 1), unit: 'kJ' },
        { label: 'Q hasta fusión', value: roundTo(Q2 / 1000, 0), unit: 'kJ' }
      ],
      'bottom-left'
    );

    if (vp.w > 430) {
      // Curva T vs Q completa (analítica) con el punto vivo y la meseta.
      const Qmax = Q2 + mIce * C_WATER * 60;
      hud.plot(
        { x: vp.x + vp.w - 250, y: vp.y + vp.h - 128, w: 235, h: 116 },
        {
          title: 'Curva de calentamiento T(Q)',
          series: [
            { fn: (Q) => this.phaseTemp(Q), samples: 120, color: 'energy', label: 'T(Q)' },
            { points: [{ x: this.Q, y: T }, { x: this.Q, y: T }], color: 'force' }
          ],
          xRange: [0, Qmax],
          yRange: [-25, 65]
        }
      );
    }
  }

  /** Modos de transferencia: barra entre focos con el canal activo. */
  _drawTransfer(scene, hud, vp) {
    const { modo } = this.params;
    const P = this.transferPower();
    const T1 = modo === 'radiacion' ? this.radC() : this.params.T1;
    const T2 = modo === 'radiacion' ? this.params.Tamb : this.params.T2;

    // Focos y barra, centrados en el origen. Antes todo el montaje vivía en la
    // franja y ∈ [2.5, 10] — la mitad superior del encuadre — y la barra de
    // conducción se dibujaba con centro en x = −8.5 y ancho 17, o sea de −17 a
    // 0: media barra quedaba fuera del lienzo.
    scene.rect(-10.5, -1.4, 2, 4, { color: 'force', width: 2, fill: 'rgba(255,107,107,0.15)' });
    scene.rect(10.5, -1.4, 2, 4, { color: 'mass', width: 2, fill: 'rgba(78,161,255,0.15)' });
    scene.label(-10.5, 1.1, `${roundTo(T1, 1)} °C`, { avoid: true, color: 'force' });
    scene.label(10.5, 1.1, `${roundTo(T2, 1)} °C`, { avoid: true, color: 'mass' });

    if (modo === 'conduccion') {
      scene.rect(0, -0.4, 19, 2.2, { color: 'textDim', width: 2, fill: 'rgba(255,171,64,0.25)' });
      scene.label(0, -2.1, `P = k·A·ΔT/L = ${roundTo(P, 1)} W`, { avoid: true, color: 'energy' });
      // Perfil lineal T(x) sobre la barra.
      for (let i = 1; i <= 6; i++) {
        const x = -9.5 + (19 * i) / 7;
        scene.body(x, 2.4, { shape: 'circle', r: 0.14, color: i % 2 ? 'force' : 'mass' });
      }
      scene.label(0, 3.1, 'Perfil lineal T(x): mismo gradiente en toda la barra', { avoid: true, color: 'textDim' });
    } else if (modo === 'conveccion') {
      // Lazo de fluido: sube caliente junto al foco, baja frío al otro lado.
      scene.polyline(
        [
          { x: -8.5, y: 0.9 }, { x: 8.5, y: 0.9 }, { x: 8.5, y: -1.4 },
          { x: -8.5, y: -1.4 }, { x: -8.5, y: 0.9 }
        ],
        { color: 'force', width: 2.5 }
      );
      scene.vector(0, 0.9, 0, 0.8, { color: 'force' });
      scene.vector(0, -1.4, 0, -0.8, { color: 'mass' });
      scene.label(0, -2.9, `P = h·A·ΔT = ${roundTo(P, 1)} W`, { avoid: true, color: 'energy' });
    } else {
      // Radiación: círculo que brilla según T (color → temperatura).
      const Tk = T1 + 273.15;
      const glow = Math.min(1, Math.max(0, (Tk - 273) / 1200));
      scene.body(0, 0, { shape: 'circle', r: 1.1 + glow * 0.5, color: glow > 0.5 ? 'force' : 'mass2' });
      scene.arc(0, 0, 1.9, 0, Math.PI * 2, { color: 'force', dash: [3, 3], alpha: 0.6 });
      scene.arc(0, 0, 3.2, 0, Math.PI * 2, { color: 'force', dash: [3, 3], alpha: 0.35 });
      scene.label(0, 3.8, `P = εσA(T⁴−Tₐ⁴) = ${roundTo(P, 2)} W`, { avoid: true, color: 'energy' });
      scene.label(6.5, -2.6, 'Calor radiado en todas direcciones', { avoid: true, color: 'textDim' });
      for (let a = 0; a < Math.PI * 2; a += Math.PI / 4) {
        scene.vector(Math.cos(a) * 1.1, Math.sin(a) * 1.1, Math.cos(a) * 1.6, Math.sin(a) * 1.6, {
          color: 'force',
          alpha: 0.4
        });
      }
    }

    hud.readout(
      [
        { label: 'P transferida', value: roundTo(P, 2), unit: 'W' },
        { label: 'ΔT', value: roundTo(T1 - T2, 1), unit: 'K' }
      ],
      'bottom-left'
    );
  }

  /* ---------- datos numéricos (§3.1) ---------- */

  readout() {
    const modo = this.params.modo;
    if (modo === 'mezcla') {
      const Teq = this.tEq();
      const sample = SAMPLES[this.params.muestra];
      const cRow = this.cVisible()
        ? { value: roundTo(this.cMetal(), 0), unit: sample ? `J/(kg·K) — ${sample.metal}` : 'J/(kg·K)' }
        : { value: '?', unit: 'J/(kg·K) — calcúlalo con T_eq' };
      return {
        'T_eq': { value: roundTo(Teq, 2), unit: '°C' },
        'T agua ahora': { value: roundTo(this.mixWater(), 1), unit: '°C' },
        'T metal ahora': { value: roundTo(this.mixMetal(), 1), unit: '°C' },
        'Q agua': { value: roundTo(this.params.m1 * C_WATER * (Teq - this.params.T1), 0), unit: 'J' },
        'Q metal': { value: roundTo(this.params.m2 * this.cMetal() * (this.params.T2 - Teq), 0), unit: 'J' },
        'c metal': cRow
      };
    }
    if (modo === 'fase') {
      return {
        'T': { value: roundTo(this.phaseTemp(this.Q), 2), unit: '°C' },
        'Q aportado': { value: roundTo(this.Q / 1000, 1), unit: 'kJ' },
        'Calor latente': { value: roundTo(this.params.mIce * L_FUSION / 1000, 0), unit: 'kJ' }
      };
    }
    return {
      'P transferida': { value: roundTo(this.transferPower(), 2), unit: 'W' },
      'ΔT': { value: roundTo(this.params.T1 - (modo === 'radiacion' ? this.params.Tamb : this.params.T2), 1), unit: 'K' }
    };
  }

  getState() {
    return { t: this.t, Q: this.Q, params: { ...this.params } };
  }

  setState(s) {
    if (!s || typeof s !== 'object') return;
    if (s.params) Object.assign(this.params, s.params);
    if (Number.isFinite(s.t)) this.t = s.t;
    if (Number.isFinite(s.Q)) this.Q = s.Q;
  }

  destroy() {}
}
