/**
 * @fileoverview PhysicsEngine — Bucle principal de simulación con timestep fijo.
 *
 * Usa requestAnimationFrame con acumulador de timestep fijo (60 FPS).
 * Soporta multiplicador de velocidad (0.1× a 5×) y callbacks onUpdate/onRender.
 */

const DEFAULT_DT = 1 / 60;
const MAX_FRAME_TIME = 0.1; // 100 ms
const MIN_SPEED = 0.1;
const MAX_SPEED = 5;
/**
 * Subpasos máximos por frame. Antes eran 5 fijos y el sobrante del acumulador
 * se descartaba: a 30 Hz con velocidad 5× la simulación se ralentizaba en
 * silencio (§3.3). Como `frameTime` ya está acotado por MAX_FRAME_TIME y la
 * velocidad por MAX_SPEED, el peor caso legítimo es ceil(0.1·5/dt) = 30: con
 * esa cota el bucle avanza siempre el tiempo prometido sin espiral de muerte.
 */
const MAX_SUBSTEPS = Math.ceil((MAX_FRAME_TIME * MAX_SPEED) / DEFAULT_DT);

/**
 * Contexto 2D estable en móviles/tablets.
 * `desynchronized:true` provoca basura de color (píxeles basura) en GPUs
 * Android/Xiaomi (Mali/Adreno); solo se considera en escritorio no-táctil.
 */
function createCanvas2d(canvas) {
  const ua = typeof navigator !== 'undefined' ? navigator.userAgent || '' : '';
  const touch =
    typeof navigator !== 'undefined' &&
    (navigator.maxTouchPoints > 0 || /Android|iPhone|iPad|iPod|Mobile/i.test(ua));
  // Preferir opaco y sin desync en táctiles / Android
  if (touch || /Android/i.test(ua)) {
    return (
      canvas.getContext('2d', { alpha: false, desynchronized: false }) ||
      canvas.getContext('2d', { alpha: false }) ||
      canvas.getContext('2d')
    );
  }
  try {
    return (
      canvas.getContext('2d', { alpha: false, desynchronized: true }) ||
      canvas.getContext('2d', { alpha: false }) ||
      canvas.getContext('2d')
    );
  } catch {
    return canvas.getContext('2d', { alpha: false }) || canvas.getContext('2d');
  }
}

export class PhysicsEngine {
  /**
   * @param {HTMLCanvasElement} canvas
   */
  constructor(canvas) {
    this.canvas = canvas;
    this.ctx = createCanvas2d(canvas);

    this._running = false;
    this._paused = false;
    this._speed = 1;
    this._accumulator = 0;
    this._lastTime = 0;
    this._frameId = null;
    this._maxSubsteps = MAX_SUBSTEPS;

    this._fps = 0;
    this._fpsFrames = 0;
    this._fpsTime = 0;
    this._dpr = 1;
    /** Duración del último frame (s), expuesta por getDelta(). */
    this._frameTime = DEFAULT_DT;
    this._resizeObs = null;
    this._resizeRaf = 0;

    this._bindResize();

    /**
     * Callback: onUpdate(dt) — llamado en cada tick de física.
     * @type {function(number): void|undefined}
     */
    this.onUpdate = null;

    /**
     * Callback: onRender(ctx, dt, elapsed) — llamado en cada frame renderizado.
     * @type {function(CanvasRenderingContext2D, number, number): void|undefined}
     */
    this.onRender = null;

    /**
     * Callback: onPauseChanged(paused) — notifica cambios de pausa.
     * @type {function(boolean): void|undefined}
     */
    this.onPauseChanged = null;

    /**
     * Callback tras redimensionar el canvas (p. ej. invalidar caché del renderer).
     * @type {function(): void|undefined}
     */
    this.onResize = null;

    this._elapsed = 0;
    this._visible = typeof document === 'undefined' || document.visibilityState !== 'hidden';
    /** El canvas está dentro del viewport (batería, §3.3). */
    this._canvasIntersecting = true;
    /** Ahorro de batería activo por defecto (se puede desactivar en ajustes). */
    this._batterySave = true;
    /** Límite de fotogramas por segundo (60 o 30) para gama baja (§3.3). */
    this._fpsLimit = 60;
    this._lastFrameAt = 0;
    this._onVis = () => {
      const visible =
        document.visibilityState !== 'hidden' &&
        (this._batterySave ? this._canvasIntersecting : true);
      if (visible && !this._visible && this._running) {
        this._lastTime = performance.now() / 1000;
        this._accumulator = 0;
      }
      this._visible = visible;
    };
    if (typeof document !== 'undefined') {
      document.addEventListener('visibilitychange', this._onVis);
    }
    // Pausar el trabajo del RAF cuando el canvas sale del viewport: el menú ya
    // corta el bucle (showCatalog → stop), pero en pestaña lateral o al hacer
    // scroll con la simulación abierta no debe seguir gastando CPU/GPU (§3.3).
    if (typeof IntersectionObserver !== 'undefined' && canvas) {
      try {
        this._intersectionObs = new IntersectionObserver(
          (entries) => {
            this._canvasIntersecting = entries[0]?.isIntersecting ?? true;
            this._onVis();
          },
          { rootMargin: '0px' }
        );
        this._intersectionObs.observe(canvas);
      } catch {
        this._intersectionObs = null;
      }
    }
  }

  /**
   * Inicia el bucle de simulación.
   */
  start() {
    if (this._running) return;
    this._running = true;
    this._paused = false;
    this._lastTime = performance.now() / 1000;
    this._tick(this._lastTime);
  }

  /**
   * Detiene el bucle por completo.
   */
  stop() {
    this._running = false;
    this._paused = false;
    if (this._frameId !== null) {
      cancelAnimationFrame(this._frameId);
      this._frameId = null;
    }
  }

  /** Libera observers (al destruir la app). El loop se corta con stop(). */
  dispose() {
    this.stop();
    if (this._resizeObs) {
      try {
        this._resizeObs.disconnect();
      } catch {
        /* ignore */
      }
      this._resizeObs = null;
    }
    if (this._intersectionObs) {
      try {
        this._intersectionObs.disconnect();
      } catch {
        /* ignore */
      }
      this._intersectionObs = null;
    }
    if (typeof document !== 'undefined' && this._onVis) {
      document.removeEventListener('visibilitychange', this._onVis);
    }
  }

  /** Aplica transform HiDPI y suavizado de forma determinista. */
  applyDprTransform() {
    if (!this.ctx) return;
    const dpr = this._dpr || 1;
    this.ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    this.ctx.imageSmoothingEnabled = true;
    try {
      this.ctx.imageSmoothingQuality = 'medium';
    } catch {
      /* ignore */
    }
  }

  /** Ajusta buffer del canvas al tamaño CSS × devicePixelRatio (nítido y estable). */
  _bindResize() {
    const apply = () => {
      const canvas = this.canvas;
      if (!canvas) return;

      // Si el lab está oculto, no redimensionar a 0×0 (basura al mostrar)
      if (canvas.offsetParent === null && canvas.getClientRects().length === 0) {
        return;
      }

      const parent = canvas.parentElement;
      const rect = canvas.getBoundingClientRect();
      let w = Math.floor(rect.width);
      let h = Math.floor(rect.height);

      // Fallback si el canvas aún no tiene caja (flex sin altura)
      if (w < 2 || h < 2) {
        const headerH = parent?.querySelector?.('.canvas-header')?.offsetHeight || 0;
        const footerH = parent?.querySelector?.('.canvas-footer')?.offsetHeight || 0;
        const pw = parent?.clientWidth || 0;
        const ph = parent?.clientHeight || 0;
        w = Math.max(2, Math.floor(pw || canvas.clientWidth || 320));
        h = Math.max(
          2,
          Math.floor((ph || canvas.clientHeight || 240) - headerH - footerH - 8)
        );
      }

      // DPR: en móviles altos (Xiaomi 2.5–3) limitar para no saturar GPU
      const rawDpr = window.devicePixelRatio || 1;
      const isCoarse =
        typeof matchMedia === 'function' && matchMedia('(pointer: coarse)').matches;
      const maxDpr = isCoarse || rawDpr > 2.25 ? 1.75 : 2;
      let dpr = Math.min(Math.max(rawDpr, 1), maxDpr);

      let bw = Math.max(1, Math.round(w * dpr));
      let bh = Math.max(1, Math.round(h * dpr));

      // Límite de textura: evita fallos/artefactos en tablets
      const maxSide = isCoarse ? 2048 : 4096;
      if (bw > maxSide || bh > maxSide) {
        const s = Math.min(maxSide / bw, maxSide / bh);
        bw = Math.max(1, Math.floor(bw * s));
        bh = Math.max(1, Math.floor(bh * s));
        dpr = bw / Math.max(w, 1);
      }

      this._dpr = dpr;
      const changed = canvas.width !== bw || canvas.height !== bh;
      if (changed) {
        canvas.width = bw;
        canvas.height = bh;
      }
      // Siempre reaplicar transform (tras width= se resetea el contexto)
      this.applyDprTransform();

      if (typeof this.onResize === 'function') {
        try {
          this.onResize();
        } catch {
          /* ignore */
        }
      }
      // Un repaint tras resize
      this.requestPaint?.();
    };

    const schedule = () => {
      if (this._resizeRaf) return;
      this._resizeRaf = requestAnimationFrame(() => {
        this._resizeRaf = 0;
        apply();
      });
    };

    apply();
    if (typeof ResizeObserver !== 'undefined') {
      this._resizeObs = new ResizeObserver(() => schedule());
      this._resizeObs.observe(this.canvas);
      if (this.canvas.parentElement) this._resizeObs.observe(this.canvas.parentElement);
      const main = document.querySelector('.main-area');
      if (main) this._resizeObs.observe(main);
    } else {
      window.addEventListener('resize', schedule);
      window.addEventListener('orientationchange', schedule);
    }
    if (typeof visualViewport !== 'undefined' && visualViewport) {
      visualViewport.addEventListener('resize', schedule);
    }
    this.resizeCanvas = apply;
  }

  /**
   * Pausa o reanuda la simulación.
   * @param {boolean} [pause] - Opcional: true para pausar, false para reanudar.
   */
  pause(pause) {
    if (pause === undefined) pause = !this._paused;
    this._paused = pause;
    this._pauseRendered = false;
    if (this.onPauseChanged) this.onPauseChanged(this._paused);
    if (!this._paused) {
      this._lastTime = performance.now() / 1000;
      // Reactivar bucle si quedó en idle de pausa
      if (this._running && this._frameId === null) {
        this._tick(this._lastTime);
      }
    }
  }

  /**
   * Reinicia la simulación (acumulador y tiempo a cero).
   */
  reset() {
    this._accumulator = 0;
    this._lastTime = performance.now() / 1000;
    this._elapsed = 0;
    this._fps = 0;
    this._fpsFrames = 0;
    this._fpsTime = 0;
  }

  /**
   * Define el multiplicador de velocidad.
   * @param {number} mult - Valor entre 0.1 y 5
   */
  setSpeed(mult) {
    this._speed = Math.max(MIN_SPEED, Math.min(MAX_SPEED, mult));
  }

  /** @returns {number} Velocidad actual */
  getSpeed() {
    return this._speed;
  }

  /**
   * Límite de fotogramas (60 o 30) para equipos de gama baja (§3.3). A 30 FPS
   * el RAF sigue corriendo pero se descarta la mitad de los frames: la física
   * recupera el tiempo perdido en el siguiente frame, así que la simulación no
   * se ralentiza, sólo se pinta la mitad de veces.
   * @param {number} fpsLimit
   */
  setFpsLimit(fpsLimit) {
    this._fpsLimit = fpsLimit === 30 ? 30 : 60;
  }

  /** @returns {number} Límite vigente. */
  getFpsLimit() {
    return this._fpsLimit;
  }

  /**
   * Activa/desactiva el ahorro de batería: pausar el trabajo del RAF cuando el
   * canvas sale del viewport (§3.3).
   * @param {boolean} on
   */
  setBatterySave(on) {
    this._batterySave = on !== false;
    this._onVis();
  }

  /** @returns {boolean} Ahorro de batería vigente. */
  getBatterySave() {
    return this._batterySave;
  }

  /** @returns {boolean} Si la simulación está pausada */
  isPaused() {
    return this._paused;
  }

  /** @returns {boolean} Si el bucle RAF está activo */
  isRunning() {
    return this._running;
  }

  /** @returns {number} Tiempo simulado transcurrido en segundos */
  getElapsed() {
    return this._elapsed;
  }

  /** @returns {number} FPS calculados */
  getFps() {
    return this._fps;
  }

  /**
   * Duración del último frame en segundos, ya acotada por MAX_FRAME_TIME.
   * La cámara la usa para que su interpolación no dependa de la tasa de
   * refresco: a 144 Hz el seguimiento iría casi tres veces más rápido (§2.2).
   * @returns {number}
   */
  getDelta() {
    return this._frameTime || DEFAULT_DT;
  }

  /**
   * Fuerza un tick de física (útil para avance por paso).
   */
  step() {
    if (this.onUpdate) this.onUpdate(DEFAULT_DT);
    this._elapsed += DEFAULT_DT;
    this.requestPaint();
  }

  /**
   * Bucle interno: requestAnimationFrame.
   * @param {number} now - Timestamp de performance.now() / 1000
   */
  _tick(now) {
    if (!this._running) return;
    this._frameId = requestAnimationFrame((t) => this._tick(t / 1000));

    // Pestaña oculta: no gastar CPU/GPU (solo reprograma el frame)
    if (!this._visible) {
      this._lastTime = now;
      this._accumulator = 0;
      return;
    }

    // Límite de fotogramas (30 FPS en gama baja, §3.3): descartar este frame.
    // El siguiente trabajo toma el frameTime acumulado y la física se pone al
    // día, de modo que la simulación no se ralentiza, sólo se pinta menos.
    if (this._fpsLimit === 30 && now * 1000 - this._lastFrameAt < 1000 / 30) {
      return;
    }
    this._lastFrameAt = now * 1000;

    // Cálculo de FPS
    this._fpsFrames++;
    this._fpsTime += this._lastTime ? now - this._lastTime : 0;
    if (this._fpsTime >= 1) {
      this._fps = Math.round(this._fpsFrames / this._fpsTime);
      this._fpsFrames = 0;
      this._fpsTime = 0;
    }

    // Timestep acumulador
    let frameTime = now - this._lastTime;
    this._lastTime = now;

    if (this._paused) {
      // En pausa: un paint y se detiene el RAF hasta unpause/requestPaint/step
      if (this.onRender && !this._pauseRendered) {
        this.onRender(this.ctx, 0, this._elapsed);
        this._pauseRendered = true;
      }
      if (this._frameId !== null) {
        cancelAnimationFrame(this._frameId);
        this._frameId = null;
      }
      return;
    }
    this._pauseRendered = false;

    // Limitar frameTime para evitar espirales de muerte
    if (frameTime > MAX_FRAME_TIME) frameTime = MAX_FRAME_TIME;
    this._frameTime = frameTime;

    this._accumulator += frameTime * this._speed;

    // Subpaso variable acotado (§18.1): por debajo de 1× el paso se escala con
    // la velocidad (min(1, speed)) en vez de escalar solo el acumulador. A 0.1×
    // sale un subpaso de dt = 1/600 por frame: movimiento continuo a 60 FPS de
    // render, diez vezes más lento en el tiempo simulado. A 1× el comportamiento
    // es idéntico al de los subpasos fijos de 1/60, y por encima de 1× nada
    // cambia (paso 1/60 y crecen los subpasos, como antes). El dt menor a
    // velocidades bajas solo mejora la precisión de integración.
    const stepDt = DEFAULT_DT * Math.min(1, this._speed);
    let steps = 0;
    while (this._accumulator >= stepDt && steps < this._maxSubsteps) {
      if (this.onUpdate) this.onUpdate(stepDt);
      this._accumulator -= stepDt;
      this._elapsed += stepDt;
      steps++;
    }
    if (this._accumulator >= stepDt) {
      this._accumulator = 0;
    }

    if (this.onRender) this.onRender(this.ctx, this._accumulator / DEFAULT_DT, this._elapsed);
  }

  /** Fuerza un repaint en pausa (p. ej. al cambiar parámetros). */
  requestPaint() {
    this._pauseRendered = false;
    if (this._running && this._paused && this._frameId === null) {
      this._lastTime = performance.now() / 1000;
      this._tick(this._lastTime);
    }
  }
}
